#!/usr/bin/env python3
"""
Shodh - local application server (used by Shodh.app on macOS).

Serves shodh.html on 127.0.0.1 only and opens the app. No dialogs.
Stopping:
  - close the Shodh window (window mode) or quit from the Dock,
  - in-app: Ask tab -> "Run offline / local AI setup" -> Stop Shodh server,
  - Ctrl+C in a terminal,
  - automatic: the page sends a heartbeat; with no open tab for
    SHODH_IDLE_SECONDS (default 600, 0 disables) the server exits by itself.
Nothing is uploaded anywhere. Only this folder is served, only to this machine.
"""
import http.server
import threading
import webbrowser
import os
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
APP_FILE = "shodh.html"
PORT_START, PORT_COUNT = 8503, 12
try:
    IDLE_SECONDS = int(os.environ.get("SHODH_IDLE_SECONDS", "600") or "0")
except ValueError:
    IDLE_SECONDS = 600


def read_build():
    """Read the build id out of shodh.html's <meta name="shodh-build">."""
    try:
        with open(APP_FILE, "r", encoding="utf-8", errors="ignore") as f:
            head = f.read(16384)
        m = re.search(r'name="shodh-build"\s+content="([^"]+)"', head)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "unknown"


BUILD = read_build()


def probe_shodh(port):
    """Return (is_shodh, build). Older builds answer plain 'shodh' with no build."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/__shodh/ping" % port, timeout=0.5) as r:
            body = r.read().decode("utf-8", "ignore")
        if not body.startswith("shodh"):
            return (False, None)
        parts = body.split("|", 1)
        return (True, parts[1] if len(parts) > 1 else "legacy")
    except Exception:
        return (False, None)


def request_quit(port):
    try:
        req = urllib.request.Request("http://127.0.0.1:%d/__shodh/quit" % port, data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=1.5):
            return True
    except Exception:
        return False


def wait_port_free(port, timeout=6.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return True
        time.sleep(0.2)
    return False


def force_kill_port(port):
    """Last resort: kill whatever PID is holding the port.
    Strategy A: lsof (built-in on macOS, most Linux systems).
    Strategy B: pkill by argv pattern (fallback if lsof not available).
    """
    killed = []
    # Strategy A: lsof — precise, kills only the process on this port
    try:
        result = subprocess.run(
            ["lsof", "-t", "-n", "-P", "-i", "TCP:%d" % port, "-s", "TCP:LISTEN"],
            capture_output=True, text=True, timeout=3
        )
        for tok in result.stdout.strip().split():
            try:
                pid = int(tok)
                os.kill(pid, signal.SIGTERM)
                killed.append(pid)
                print("  SIGTERM -> PID %d (port %d)" % (pid, port))
            except Exception:
                pass
    except FileNotFoundError:
        pass  # lsof not installed; fall through
    except Exception as e:
        print("  lsof error:", e)

    # Strategy B: pkill by script name — broader but safe (one server per machine)
    if not killed:
        try:
            r = subprocess.run(["pkill", "-f", "shodh_server.py"],
                               capture_output=True, timeout=3)
            if r.returncode == 0:
                print("  pkill shodh_server.py succeeded (lsof fallback)")
                killed = ["pkill"]
        except Exception as e:
            print("  pkill fallback error:", e)

    if not killed:
        print("  force_kill_port: could not identify process on port %d" % port)
    return bool(killed)


def find_free_port():
    for p in range(PORT_START, PORT_START + PORT_COUNT):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return 0


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k):
        pass

    def _touch(self):
        try:
            self.server.last_hit = time.time()
        except Exception:
            pass

    def _nocache(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")

    def end_headers(self):
        # applied to every response, including SimpleHTTPRequestHandler's file serving
        self._nocache()
        super().end_headers()

    def _plain(self, code, body):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._touch()
        if self.path.startswith("/__shodh/ping"):
            self._plain(200, ("shodh|" + BUILD).encode("utf-8"))
            return
        if self.path in ("", "/"):
            self.send_response(302)
            self.send_header("Location", "/" + APP_FILE)
            self.end_headers()
            return
        if self.path.split("?")[0].endswith("/" + APP_FILE):
            try:
                self.server.served_app = True
            except Exception:
                pass
        return super().do_GET()

    def do_POST(self):
        self._touch()
        if self.path.startswith("/__shodh/quit"):
            self._plain(200, b"stopping")
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        self._plain(404, b"not found")


def make_httpd(port):
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.last_hit = time.time()
    httpd.served_app = False
    return httpd


def idle_monitor(httpd):
    """Exit quietly once the page has been served and no tab has pinged for a while."""
    if IDLE_SECONDS <= 0:
        return
    step = min(15, max(1, IDLE_SECONDS // 4))

    def loop():
        while True:
            time.sleep(step)
            try:
                if httpd.served_app and (time.time() - httpd.last_hit) > IDLE_SECONDS:
                    threading.Thread(target=httpd.shutdown, daemon=True).start()
                    return
            except Exception:
                return

    threading.Thread(target=loop, daemon=True).start()


def open_ui(url):
    # Prefer a chromeless "app window" when a Chromium-family browser exists (macOS).
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium"):
            if os.path.isdir("/Applications/%s.app" % app):
                try:
                    subprocess.Popen(["open", "-na", app, "--args", "--app=" + url],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    pass
    try:
        webbrowser.open(url)
    except Exception:
        pass


def main():
    if not os.path.exists(APP_FILE):
        sys.exit("shodh.html not found next to shodh_server.py (%s)" % HERE)

    # single instance, version aware: reuse the SAME build, replace an older one.
    # Replacing keeps the same port, so the browser origin (and your saved data)
    # is unchanged.
    port = 0
    for p in range(PORT_START, PORT_START + PORT_COUNT):
        running, other_build = probe_shodh(p)
        if not running:
            continue
        url = "http://127.0.0.1:%d/%s" % (p, APP_FILE)
        if other_build == BUILD:
            print("Shodh (build %s) already running -> %s" % (BUILD, url))
            open_ui(url)
            return
        print("Replacing older Shodh (build %s) with build %s on port %d"
              % (other_build, BUILD, p))
        request_quit(p)
        if wait_port_free(p):
            port = p
            break
        print("Could not stop the old Shodh; opening the running one instead.")
        open_ui(url)
        return

    if not port:
        port = find_free_port()
    if not port:
        sys.exit("No free port in %d-%d." % (PORT_START, PORT_START + PORT_COUNT - 1))
    url = "http://127.0.0.1:%d/%s" % (port, APP_FILE)

    httpd = make_httpd(port)
    try:
        signal.signal(signal.SIGTERM,
                      lambda *_: threading.Thread(target=httpd.shutdown, daemon=True).start())
    except Exception:
        pass

    print("Shodh build %s running at %s" % (BUILD, url))
    if IDLE_SECONDS > 0:
        print("It stops by itself ~%d min after the last Shodh tab closes." % max(1, IDLE_SECONDS // 60))
    threading.Timer(0.7, lambda: open_ui(url)).start()
    idle_monitor(httpd)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    print("Shodh stopped.")


if __name__ == "__main__":
    main()
