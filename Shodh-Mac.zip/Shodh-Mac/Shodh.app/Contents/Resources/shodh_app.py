#!/usr/bin/env python3
"""Shodh window app - native window (pywebview) hosting the local server.

Adds a native "Save As" bridge: the web app calls window.pywebview.api.shodhSave
so exports (.bib/.ris/.csv/.txt/.svg/.json/.png) open a real save dialog and are
written wherever the user chooses, instead of navigating (and freezing) the
WKWebView with a blob: URL.
"""
import base64
import os
import sys
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
os.environ["SHODH_IDLE_SECONDS"] = "0"   # window lifecycle controls quitting

import shodh_server as SS
import webview


def _save_dialog_type():
    try:
        return webview.FileDialog.SAVE
    except AttributeError:
        return webview.SAVE_DIALOG


class ShodhApi:
    def __init__(self):
        self._window = None

    def shodhSave(self, filename, content_b64):
        """Show Save As, write base64 bytes to the chosen path. Returns a dict."""
        try:
            win = self._window
            if win is None:
                return {"ok": False, "error": "no window"}
            result = win.create_file_dialog(_save_dialog_type(), save_filename=filename)
            path = None
            if isinstance(result, (list, tuple)):
                path = result[0] if result else None
            elif isinstance(result, str):
                path = result
            if not path:
                return {"ok": False, "canceled": True}
            data = base64.b64decode(content_b64)
            with open(path, "wb") as f:
                f.write(data)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def main():
    try:
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        webview.settings["ALLOW_DOWNLOADS"] = True
    except Exception:
        pass

    # Build-aware single instance:
    #   same build already running  -> reuse its port (no new server)
    #   older build running         -> kill it, start the new server on the SAME port
    #                                  (same origin = IndexedDB data is preserved)
    #   nothing running             -> start fresh on any free port
    #
    # The URL always includes ?v=<build> as a cache-buster so WKWebView never
    # serves a stale cached copy of shodh.html from a previous version.
    def app_url(port):
        return "http://127.0.0.1:%d/%s?v=%s" % (port, SS.APP_FILE, SS.BUILD)

    url = None
    httpd = None
    for p in range(SS.PORT_START, SS.PORT_START + SS.PORT_COUNT):
        running, their_build = SS.probe_shodh(p)
        if not running:
            continue
        if their_build == SS.BUILD:
            # Exact same build already up — just open a window to it.
            print("Shodh (build %s) already running on port %d" % (SS.BUILD, p))
            url = app_url(p)
            break
        # Different (older) build found — replace it.
        print("Replacing old Shodh build '%s' with '%s' on port %d" % (their_build, SS.BUILD, p))
        SS.request_quit(p)                        # polite ask (may not exist on old builds)
        if not SS.wait_port_free(p, timeout=3.0): # if still alive…
            SS.force_kill_port(p)                 # …force kill via lsof / pkill
        if SS.wait_port_free(p, timeout=5.0):
            httpd = SS.make_httpd(p)
            threading.Thread(target=httpd.serve_forever, daemon=True).start()
            url = app_url(p)
            print("New server started on port %d (build %s)" % (p, SS.BUILD))
        else:
            print("Could not reclaim port %d; will use a new port." % p)
        break

    if url is None:
        port = SS.find_free_port()
        if not port:
            sys.exit("No free port for Shodh.")
        httpd = SS.make_httpd(port)
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        url = app_url(port)
        print("Shodh started on port %d (build %s)" % (port, SS.BUILD))

    api = ShodhApi()
    store = os.path.join(os.path.expanduser("~/Library/Application Support/Shodh"), "webdata")
    try:
        os.makedirs(store, exist_ok=True)
    except Exception:
        store = None

    window = webview.create_window("Shodh", url, width=1320, height=880,
                                   min_size=(940, 620), js_api=api)
    api._window = window
    try:
        webview.start(private_mode=False, storage_path=store)
    except TypeError:
        webview.start()
    finally:
        if httpd is not None:
            try:
                httpd.shutdown()
            except Exception:
                pass


if __name__ == "__main__":
    main()
