# Shodh for Mac (शोध) — v1.1

Offline literature review that runs entirely on your computer. Nothing is uploaded anywhere.

## What's new in v1.1
- **Opens in its own window** like a normal Mac app (no browser tabs, no Terminal). Close the window (or Cmd+Q) to quit.
- The floating "Stop Shodh" dialog is **gone**. The background server now also stops **by itself** ~10 minutes after the last Shodh tab/window closes.
- Arrow keys **scroll** at Stage 2 (they no longer skip records — that was a bug). Skip is `S`.
- **Notes**: select any text in an abstract (Stage 2) or a source passage (Ask) → click the "+ Note" button that appears; or use "+ Add note" on the card. Export all notes as .txt from the Export tab. Notes ride inside JSON backups.
- **Restore from backup** on the Import tab (Export-tab JSON → new review).

## Install & first launch
1. Drag **Shodh.app** to **Applications**.
2. **First launch: right-click → Open → Open** (the app is unsigned, so macOS warns on plain double-click; after once, double-click works). If macOS says "damaged": `xattr -dr com.apple.quarantine /Applications/Shodh.app`
3. On the very first launch Shodh sets up its window engine (one-time, needs internet, 10–60 s — you'll see a notification). Then the Shodh window opens.
   - If that setup can't happen (no internet, unusual Python), Shodh falls back to an app-style Chrome/Edge window if installed, else your normal browser. Everything works the same.

Requires Python 3 (Homebrew / python.org / Apple's all fine).

## IMPORTANT — moving your existing library into the window app
The window app has its **own storage**. Reviews you built in Safari/Chrome will NOT appear in it automatically (and vice-versa). To move a review:
1. In the browser where your data lives: **Export tab → Full project — JSON**.
2. In the Shodh window: **Import tab → Restore a Shodh backup (.json)**.
3. PDFs are not inside JSON backups — re-attach them where needed (decisions, notes, and metadata all transfer).

**Please verify persistence once:** create/restore a review in the window, quit, reopen — it should still be there. It is configured to persist, but this is the one path I could not execute on a real Mac.

## Stopping Shodh
Close the window / Cmd+Q. In browser mode: quit from the Dock, use Ask → "Run offline / local AI setup" → **Stop Shodh server**, or just close the tab — the server exits by itself ~10 min later. (Heads-up: browsers throttle background tabs, so a long-backgrounded tab may let the server auto-stop; the open page keeps working — only a reload would need a relaunch.)

## Honest limitations
- Unsigned & not notarized: other people you share this with will see the same Gatekeeper warning. Frictionless distribution requires an Apple Developer account (paid — I believe ~US$99/yr, verify with Apple) + notarization.
- The native-window path depends on `pywebview` installing against your Python (one-time). If it fails, the browser fallback is automatic and equivalent.
- macOS-specific behavior (Gatekeeper, the window itself) was assembled per Apple's documented formats but could not be executed in the Linux build environment — your first launch is the real test. Everything server-side was executed and verified.
- No OCR; keyword (not semantic) retrieval; single-machine reviewer blinding; PRISMA counts are a working aid to verify before submission.
