#!/bin/bash
# Fallback starter: runs the same server in a visible Terminal window.
cd "$(dirname "$0")/Shodh.app/Contents/Resources" || exit 1
echo "Starting Shodh... (leave this window open; press Ctrl+C to stop)"
exec python3 shodh_server.py
